<template>
  <div class="profile">
    <h1>User Profile</h1>
    <p>Manage your account, subscription, and redeemed coupons here.</p>
  </div>
</template>

<script>
export default {
  name: "UserProfile" // changed from "Profile" to "UserProfile"
}
</script>

<style scoped>
/* Profile page styles */
</style>
